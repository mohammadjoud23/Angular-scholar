// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCMiTF7XNAqg7k0e467ecqUbO1JFRCDXMo",
    authDomain: "fir-cdff0.firebaseapp.com",
    projectId: "fir-cdff0",
    storageBucket: "fir-cdff0.appspot.com",
    messagingSenderId: "774255142625",
    appId: "1:774255142625:web:a3763c076634bb6d9579a0",
    measurementId: "G-WGYTM6LP73"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
