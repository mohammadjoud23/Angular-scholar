export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCMiTF7XNAqg7k0e467ecqUbO1JFRCDXMo",
    authDomain: "fir-cdff0.firebaseapp.com",
    projectId: "fir-cdff0",
    storageBucket: "fir-cdff0.appspot.com",
    messagingSenderId: "774255142625",
    appId: "1:774255142625:web:a3763c076634bb6d9579a0",
    measurementId: "G-WGYTM6LP73"
  }
};
