import { UserImagePipe } from './user-image.pipe';

describe('UserImagePipe', () => {
  it('create an instance', () => {
    const pipe = new UserImagePipe();
    expect(pipe).toBeTruthy();
  });
});
