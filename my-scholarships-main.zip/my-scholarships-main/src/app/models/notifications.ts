export interface Notifications {
  id: number;
  user_id: number;
  title: string;
  message: string;
  //   data: Noti[];
}

export interface Noti {
  id: number;
  user_id: number;
  title: string;
  message: string;
}
