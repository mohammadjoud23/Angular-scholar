import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managing',
  templateUrl: './managing.component.html',
  styleUrls: ['./managing.component.scss']
})
export class ManagingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
